# Matlab code to generate RTI data



Environment_P6_SNR30_40_50.m initializes environment parameters for generating training data and testing data

genData.m generate training/testing samples

Estimate_slf_ENR.m is the ENR estimation function


Need to install [Matlab CVX package](http://cvxr.com/cvx/)
