function [ darray ] = f_gen_darray( nodepos )
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% GENERATE THE INTER-NODE DISTANCES FOR ALL TIME VALUES
% nodepos (MxTw) - the (complex) location of each node (row) at each time (col)
% darray(:,:,j) - each link's link length at time j, total size M x M x Tw
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 
darray = NaN(size(nodepos,1),size(nodepos,1),size(nodepos,2));
for i = 1:size(nodepos,2)
    nvect = nodepos(:,i)'; 
    [m, n] = ndgrid(1:size(nvect,2),1:size(nvect,2));
    darray(:,:,i) =  abs( nvect(m) - nvect(n) );
end

end

