function [ Wi ] = f_gen_Wi( nodepos, pixelsize, imgorg, imgdims, i1, i2 )
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% f_gen_Wi : GENERATE A WEIGHT MATRIX FOR THE ITH LINK (BIN) IN THE SYSTEM
% This function calls f_pixel_weights to compile all the relevant weights for all measurements taken
% between a given pair of nodes
% nodepos - array of node positions with time
% pixelsize - l/w of each square pixel (m)
% imgorg - [x y] position of lower left corner of image(m)
% imgdims - [rows cols] of the image
% i1 - node index of the TX, i2 - node index of the RX  (link i)
% Wi ( ni x K ) - weights for link i 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

ni = size(nodepos,2); %# of time steps
K = imgdims(1)*imgdims(2); %pixel count

Wi = NaN(ni,K);
if i1 ~= i2 
    for j = 1:ni %loop over individual link's measurements
        p1 = [real(nodepos(i1,j)) imag(nodepos(i1,j))];
        p2 = [real(nodepos(i2,j)) imag(nodepos(i2,j))];
%         Wi(j,:) = f_pixel_weights(imgdims,pixelsize,imgorg,p1,p2);
        Wi(j,:) = f_pixel_weights_2(imgdims,pixelsize,imgorg,p1,p2);
    end
else
    Wi = zeros(ni,K); %invalid link
end

end

