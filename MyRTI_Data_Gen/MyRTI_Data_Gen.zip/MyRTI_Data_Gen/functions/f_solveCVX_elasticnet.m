function [ betahat_EN, bhatEN, lambda1] = f_solveCVX_elasticnet(M, Tw, imgdims, y_vpeak, Gamma, ...
                                        X, Z, lambda1_range, lambda2, valct)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% SOLVE THE SYSTEM USING ELASTIC NET REGULARIZATION AND CVX           
% Inputs:
%   M - CSOT antennas/nodes (16)  Tw: number of time steps in the data
%   imgdims - rows,cols of image
%   y_vpeak - data vector of RSS values
%   X, Z - fixed effects design matrices
%   lambda2 - 2-norm reg. parameter found from previous search
%   lambda1_range - vector of 1norm reg. parameters to try
% Outputs:
%   betahat_EN - solution found from the elastic net, bhat_EN - solution for the bias paramters
%   lambda1 - value found for lambda1 using cross validation
%   valct - data points to remove per link for validation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  

N = M*(M-1)-M; %CSOT useful link count
ni = Tw; %data points per link (time steps)

if length(lambda1_range) == 1 %lambda value is given
    % solve the model with the given lambda1 %
    lambda1 = lambda1_range(1);
    cvx_begin
        variable betahat_EN(imgdims(1)*imgdims(2),1) nonnegative
        variable bhatEN(size(Z,2),1) nonnegative
        minimize norm(y_vpeak - X*betahat_EN - Z*bhatEN) + lambda1 * norm(betahat_EN,1) + ...
                        lambda2 * norm(Gamma * betahat_EN);
    cvx_end
    
    betahat_EN = betahat_EN * (1 + lambda2); %naiive EN correction of overshrinkage

else

    %SEPARATE THE TRAINING (BIG) AND VALIDATION (SMALL) DATA SETS
    rem_inds = NaN(valct,N);
    for ii = 1:N 
        rem_inds(:,ii) = randperm(ni,valct)'; 
    end
    rem_inds = sort(rem_inds,1); rem_inds = reshape(rem_inds,[],1);
    link_inds = kron((0:N-1)',ones(valct,1)) * Tw + 1;    %offset into each link's data
    rem_inds = rem_inds + link_inds - 1; %absolute indices to remove in data vector

    y_val = y_vpeak(rem_inds);   %validation data
    X_val = X(rem_inds,:);       %validation model mat
    Z_val = Z(rem_inds,:);       %"" "" 
    y_trn = y_vpeak; y_trn(rem_inds) = []; %training data
    X_trn = X; X_trn(rem_inds,:) = [];     %training model mats
    Z_trn = Z; Z_trn(rem_inds,:) = [];


    betahat_crossval = NaN([imgdims length(lambda1_range)]); %store the image estimates
    bhat_crossval = NaN(size(Z,2),length(lambda1_range)); %store the bias estimates
    pred_err = NaN(1,length(lambda1_range)); %store prediction errors

    for ind = 1:length(lambda1_range);
        lambda1 = lambda1_range(ind);
        %solve the CVX elastic net model for given parameters
        [beta_hat, bhat] = f_CVX_ENet(imgdims,y_trn,X_trn,Z_trn,Gamma,lambda1,lambda2);
        
        betahat_crossval(:,:,ind) = reshape(beta_hat,imgdims); 
        bhat_crossval(:,ind) = bhat;

        % compute the prediction error for the given lambda's  %
        pred_err(ind) = norm( y_val - X_val*beta_hat - Z_val*bhat );

%         %PLOT DEBUG CODE%
%         figure('name',['ENet Solution, lambda1 = ' num2str(lambda1) ', lambda2 = ' num2str(lambda2)]); 
%         imshow(reshape(beta_hat,imgdims),[0,max(beta_hat(:))],'initialmagnification','fit');

    end

    % find the best lambda from the search %
    min_err = min(pred_err); %lowest total error
    err_new = min_err + std(pred_err); %one standard error rule
    [~,min_ind] = min( abs( pred_err - err_new ) ); 
    lambda1 = lambda1_range(min_ind); 

    % solve the model with the lambda1 result and full data set %
    cvx_begin quiet
        variable betahat_EN(imgdims(1)*imgdims(2),1) nonnegative
        variable bhatEN(size(Z,2),1) nonnegative
        minimize norm(y_vpeak - X*betahat_EN - Z*bhatEN) + lambda1 * norm(betahat_EN,1) + ...
                        lambda2 * norm(Gamma * betahat_EN);
    cvx_end
    
    betahat_EN = betahat_EN * (1 + lambda2); %naiive EN correction of overshrinkage

%     %DEBUG PLOT CODE%
%     figure('name','Validation Errors'); semilogx(lambda1_range,pred_err);
%     save('I:\Research\RTI Mixed Models\matlab\workspace savedata\lambda1_search'); %store for analysis

end

end

