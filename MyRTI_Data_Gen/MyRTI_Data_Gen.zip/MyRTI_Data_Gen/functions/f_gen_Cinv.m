function [ Cinv ] = f_gen_Cinv( imgdims, pixelsize, kappa  )
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% COMPUTE SPATIAL COVARIANCE MATRIX AND ITS INVERSE           %
% inputs:                                                     %
%   imgdims (1x2) rows, cols in the image                     %
%   pixelsize - physical size of the sides of a pixel (m)     %
%   kappa - a priori covar spread parameter (m)               %
% outputs:                                                    %
%   Cinv - the inverse of the spatial covariance function     %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
M = imgdims(1); N = imgdims(2); Y = pixelsize; X = pixelsize;

%grid: store y,x coords of pixel m,n (row,col) (center) as a vector:
%grid(r,:) gives the y,x coordinates of pixel r
[m, n] = ndgrid(0:M-1,0:N-1);  
grid = [-m*Y-Y/2   n*X+X/2];    grid = reshape(grid,M*N,2);                           

%dmn: distance from pixel m to pixel n 
[m, n] = ndgrid(1:M*N,1:M*N); 
dmn = sqrt( sum( (grid(m,:)-grid(n,:)).^2 ,2) ); 
dmn = reshape(dmn,M*N,M*N);

%Cg: spatial covariance matrix: exponential function of pixel distance
C = exp(-dmn / kappa); 
Cinv = inv(C);

end

