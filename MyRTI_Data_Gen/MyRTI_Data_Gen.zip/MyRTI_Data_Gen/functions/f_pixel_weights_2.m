function Xij = f_pixel_weights_2(imgdims, pixelsize, imgorg, p1, p2)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% COMPUTES THE PIXEL WEIGHTS FOR SINGLE MEASUREMENT J OF LINK I (tomographic projection) %
% Xij (1 x numpixels) - row vector of weights for the given points. normalized ellipse   %
% imgdims (1x2) - number of [rows cols] in the image. the image is assumed to reside in  %
%   the first quadrant, with the lower left corner at the origin                         %
% pixelsize - the PHYSICAL length of a pixel's sides, assumed to be square pixels (m)    %
% imgorg (1x2) - physical [x y] location of the lower left corner of the image (m)       %
% p1, p2 (1x2) - [x y] locations of the two nodes of interest (m)                        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% normalized ellipse model
d_real = norm(p1-p2);    %real distance of the tranceievers pair

p1 = (p1' - imgorg') / pixelsize; 
p2 = (p2' - imgorg') / pixelsize; %scale points to "single units"
fai = (p1-p2)/norm(p1-p2);   %projection vector
c = (p1+p2)/2;               % center of the ellipse
d = norm(p1-p2);
lanpt = 0.1*d;

K = imgdims(1)*imgdims(2); %pixel count
sx = NaN(K,1);  sy = NaN(K,1);   %x and y coodinates of pixels           
px = NaN(K,1);  py = NaN(K,1);
bb = zeros(1,K);

NI = 0;
for j=1:imgdims(2)   %col
    for i=1:imgdims(1)   %row
        NI = NI + 1;          % number of pixels
        sx(NI,1) = j-0.5;
        sy(NI,1) = imgdims(1)-i+0.5;
        px(NI,1) = fai(1)*(sx(NI,1)-c(1))+fai(2)*(sy(NI,1)-c(2));
        py(NI,1) = -fai(2)*(sx(NI,1)-c(1))+fai(1)*(sy(NI,1)-c(2));
        % It should be temp = px(NI,1)^2/((d/2)^2+lanpt^2)+py(NI,1)^2/(lanpt^2);
        % Since the distance between transceivers is 2c=d rather than c.
        temp = px(NI,1)^2/(d^2+lanpt^2)+py(NI,1)^2/(lanpt^2);
        if temp<1
            bb(1,NI) = 1/sqrt(d_real);
        end
    end 
end

Xij = bb;

% %DEBUG plot code


end
