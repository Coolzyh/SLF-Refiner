function Xij = f_pixel_weights_3(imgdims, pixelsize, imgorg, p1, p2)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% COMPUTES THE PIXEL WEIGHTS FOR SINGLE MEASUREMENT J OF LINK I (tomographic projection) %
% Xij (1 x numpixels) - row vector of weights for the given points. inverse area ellipse %
% imgdims (1x2) - number of [rows cols] in the image. the image is assumed to reside in  %
%   the first quadrant, with the lower left corner at the origin                         %
% pixelsize - the PHYSICAL length of a pixel's sides, assumed to be square pixels (m)    %
% imgorg (1x2) - physical [x y] location of the lower left corner of the image (m)       %
% p1, p2 (1x2) - [x y] locations of the two nodes of interest (m)                        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% inverse area ellipse model

freq_RF = 2.4e9;  % RF 2.4 GHz
lanpt = 3e8/freq_RF;    %wave length

p1 = p1' - imgorg';
p2 = p2' - imgorg'; %scale points to "single units"
fai = (p1-p2)/norm(p1-p2);   %projection vector
c = (p1+p2)/2;               % center of the ellipse
d = norm(p1-p2);

K = imgdims(1)*imgdims(2); %pixel count
bb = zeros(1,K);
u = NaN(1,K);
u_max = 0.5*sqrt(1*lanpt*d);

NI = 0;
for j=1:imgdims(2)   %col
    for i=1:imgdims(1)   %row
        NI = NI + 1;          % number of pixels
        sx = (j-0.5)*pixelsize;
        sy = (imgdims(1)-i+0.5)*pixelsize;
        px = fai(1)*(sx-c(1))+fai(2)*(sy-c(2));
        py = -fai(2)*(sx-c(1))+fai(1)*(sy-c(2));
        a0 = 1; b0 = -(px^2+py^2-d^2); c0 = -py^2*d^2;
        u_2 = (-b0 + sqrt(b0^2-4*a0*c0))/(2*a0);
        u(1,NI) = sqrt(u_2);
        if u(1,NI)<u_max
            if u(1,NI)<0.05
                u(1,NI) = 0.05;
            end
            bb(1,NI) = 1/(pi*u(1,NI)*sqrt(u(1,NI)^2+d^2));
        end
    end 
end
Xij = bb;

% imshow(reshape(Xij,[40,40]),[0 max(Xij)])

% %DEBUG plot code

end
