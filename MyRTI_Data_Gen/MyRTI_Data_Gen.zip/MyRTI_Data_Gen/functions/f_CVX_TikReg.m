function [ beta_hat, bhat ] = f_CVX_TikReg(imgdims, y_vpeak, X, Z, lambda2, Gamma )
%%% A WRAPPER FUNCTION TO ALLOW CVX CODE TO RUN IN A PARFOR LOOP %%%
%%% THIS ONE COMPUTES THE TIKHONOV REGULARIZATION

cvx_begin quiet
    variable beta_hat(imgdims(1)*imgdims(2),1) nonnegative
    variable bhat(size(Z,2),1) nonnegative
    minimize norm(y_vpeak - X*beta_hat - Z*bhat) + lambda2 * norm(Gamma * beta_hat)
cvx_end


end

