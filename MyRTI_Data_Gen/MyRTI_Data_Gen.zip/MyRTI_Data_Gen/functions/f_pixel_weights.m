function Xij = f_pixel_weights(imgdims, pixelsize, imgorg, p1, p2)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% COMPUTES THE PIXEL WEIGHTS FOR SINGLE MEASUREMENT J OF LINK I (tomographic projection) %
% Xij (1 x numpixels) - row vector of weights for the given points. a pixel's weight is  %
%   equal to the length of the line segment passing through it from p1 to p2.            %
% imgdims (1x2) - number of [rows cols] in the image. the image is assumed to reside in  %
%   the first quadrant, with the lower left corner at the origin                         %
% pixelsize - the PHYSICAL length of a pixel's sides, assumed to be square pixels (m)    %
% imgorg (1x2) - physical [x y] location of the lower left corner of the image (m)       %
% p1, p2 (1x2) - [x y] locations of the two nodes of interest (m)                        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% tomographic line integral model
TOL = 10^-12; %tolerance prevents segments moving exactly through a pixel corner
p1 = (p1.' - imgorg.') ./ pixelsize; p2 = (p2.' - imgorg.') ./ pixelsize; %scale points to "single units"
m = (p2(2) - p1(2)) / (p2(1) - p1(1)); %line slope

minpt = min(p1(1),p2(1)); maxpt = max(p1(1),p2(1));         %ensure correct ordering of pts
int_x = (floor(minpt + TOL) + 1):(ceil(maxpt - TOL) - 1);   %integer x coords of crossed pixels         
isects1 = [int_x ; (m * (int_x - p1(1)) + p1(2))];          %compute corresponding y values        

minpt = min(p1(2),p2(2)); maxpt = max(p1(2),p2(2));         %ensure correct ordering of pts
int_y = (floor(minpt + TOL) + 1):(ceil(maxpt - TOL) - 1);   %integer y coords of crossed pixels
isects2 = [((int_y - p1(2)) / m + p1(1)) ; int_y];          %corresponding x values

%compile all intersection points and sort, remove out of bounds crossings
isect_all = [p1 p2 isects1 isects2];
isect_all = sortrows(isect_all.', 1).';
isect_all = sortrows(isect_all.', 2).';
isect_all = round(isect_all / TOL) * TOL;
outofbounds = isect_all(1,:) < 0 | isect_all(1,:) > imgdims(2) | ...
    isect_all(2,:) < 0 | isect_all(2,:) > imgdims(1);
isect_all(:,outofbounds) = []; %remove pixel crossings outside the image bounds

if isempty(isect_all) %if no line segments are inside the image
    Xij = zeros(1,imgdims(1)*imgdims(2)); 
    return 
end

%faster version of "unique" function, by Ethan:
isect_all = isect_all(:,([isect_all(1,1:end-1) NaN] ~= [isect_all(1,2:end) NaN]) | ([isect_all(2,1:end-1) NaN] ~= [isect_all(2,2:end) NaN]));

starts = isect_all(:,1:end-1);   %line segment "start points" ie, all but p2
ends = isect_all(:,2:end);       %"" "end points", all but p1
idx = ceil((starts + ends) / 2); %get indices of crossed pixels

%assign weights based on each segment's length, and scale back to physical pixel size
Xij = zeros(imgdims);
idx = sub2ind(imgdims, idx(2,:), idx(1,:));
Xij(idx) = pixelsize * sqrt((starts(1,:) - ends(1,:)).^2 + (starts(2,:) - ends(2,:)).^2);
Xij = flipud(Xij); %flip y axis; view as an xy map, not an image
Xij = reshape(Xij,1,imgdims(1)*imgdims(2));

% %DEBUG plot code
% Xij=reshape(Xij,imgdims(1),imgdims(2)); d = norm((p2-p1)*pixelsize);
% figure; hold on; set(gca,'YDir','normal');
% imshow(Xij,[0 max(Xij(:))],'initialmagnification','fit');
% plot(linspace(p1(1),p2(1),50)+0.5,imgdims(1)-linspace(p1(2),p2(2),50)+0.5,'LineWidth',1)
% plot(isect_all(1,:)+0.5,imgdims(1)-isect_all(2,:)+0.5,'gx')
% disp(['sum of weights = ' num2str(sum(Xij(:)))]);
% disp(['dist, p1-p2 = ' num2str(d)]);
% Xij = reshape(Xij,1,imgdims(1)*imgdims(2)); pause; close;
end
