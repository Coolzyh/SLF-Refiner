function [ betahat_crossval, lambda2_crossval ] = f_lambda2_Kcrossval(M, Tw, imgdims, Gamma, ...
                                                lambda2_range, X, Z, y_vpeak )
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% SOLVE FOR THE VALUE OF LAMBDA2 USING TIKHONOV REGULARIZATION AND CROSS VALIDATION
%       This function finds the value of the lambda2 parameter (that goes with the 2 norm error 
% term) using leave-k-out cross validation.  One data point is left out from each link, then the
% model is estimated using the remaining data for a given value of lambda2. Different values of
% lambda2 are tried, and the lambda2 is chosen which best estimates the left out data.
% The lambda2 parameter is found first, with lambda1 (1 norm penalty) set to 0, so that all
% variables are included in the model. 
% OUTPUTS: 
%     betahat_crossval: MxN estimated image
%     lambda2_crossval: best value found for estimating the left-out data. (squared error)
% INPUTS:
%     imgdims: size of image (rows, columns)
%     Gamma: the cholesky decomp of Cinv
%     lambda2_range: vector of lambda values to try -- e.g. beg:inc:end
%     X: pixel weight matrix
%     Z: design matrix for bias parameters
%     y_vpeak: data vector of RSS values
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

N = M*(M-1)-M; %CSOT useful link count
ni = Tw; %data points per link (time steps)
valct = 5; %data points to remove per link for validation

%SEPARATE THE TRAINING (BIG) AND VALIDATION (SMALL) DATA SETS
rem_inds = NaN(valct,N);
for ii = 1:N 
    rem_inds(:,ii) = randperm(ni,valct)'; 
end
rem_inds = sort(rem_inds,1); rem_inds = reshape(rem_inds,[],1);
link_inds = kron((0:N-1)',ones(valct,1)) * Tw + 1;    %offset into each link's data
rem_inds = rem_inds + link_inds - 1; %absolute indices to remove in data vector

y_val = y_vpeak(rem_inds);   %validation data
X_val = X(rem_inds,:);       %validation model mat
Z_val = Z(rem_inds,:);       %"" "" 
y_trn = y_vpeak; y_trn(rem_inds) = []; %training data
X_trn = X; X_trn(rem_inds,:) = [];     %training model mats
Z_trn = Z; Z_trn(rem_inds,:) = []; 

pred_err = zeros(1,length(lambda2_range));               %store calc'ed prediction errors
betahat_crossval = NaN([imgdims length(lambda2_range)]); %store the image estimates
bhat_crossval = NaN(size(Z,2),length(lambda2_range));    %store bhat values
ind = 1;
for lambda2 = lambda2_range

    cvx_begin %solve the CVX tikhonov model for given parameters
            variable beta_hat(imgdims(1)*imgdims(2),1) nonnegative
            variable bhat(size(Z,2),1) nonnegative
            minimize norm(y_trn - X_trn*beta_hat - Z_trn*bhat) + lambda2 * norm(Gamma * beta_hat)
    cvx_end
    betahat_crossval(:,:,ind) = reshape(beta_hat,imgdims);
    bhat_crossval(:,ind) = bhat;
    
    % compute the prediction error for the given lambda2  %
    pred_err(ind) = norm( y_val - X_val*beta_hat - Z_val*bhat );

    %PLOT DEBUG CODE%
    figure('name',['Tik. Reg. Solution, lambda2 = ' num2str(lambda2)]); 
    imshow(reshape(beta_hat,imgdims),[0,7],'initialmagnification','fit');
    
    ind = ind + 1;
end

% find the optimal lambda2 from the search %
[~,ind] = min(pred_err); %index of lowest total error
lambda2_crossval = lambda2_range(ind);
betahat_crossval = betahat_crossval(:,:,ind); 

%DEBUG PLOT CODE%
figure('name','Validation Errors'); semilogx(lambda2_range,pred_err);
save('I:\Research\RTI Mixed Models\matlab\Reg Param Search Results\lambda2_search'); %store for analysis

end

