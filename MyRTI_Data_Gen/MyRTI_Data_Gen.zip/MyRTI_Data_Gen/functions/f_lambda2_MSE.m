function [ thetahat_MSE, lambda2_MSE ] = f_lambda2_MSE( imgdims, Gamma, ...
                                                lambda2_range, X, Z, y_vpeak, theta )
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% SOLVE FOR THE VALUE OF LAMBDA2 GIVING BEST MSE PERFORMANCE 
%       This function finds the value of the lambda2 parameter (that goes with the 2 norm error 
% term).  
% The lambda2 parameter is found first, with lambda1 (1 norm penalty) set to 0, so that all
% variables are included in the model. REQUIRES parallel computing toolbox to use parfor.
% OUTPUTS: 
%     betahat_MSE: best MxN estimated image
%     lambda2_MSE: optimum value found for lambda2
% INPUTS:
%     imgdims: size of image (rows, columns)
%     Gamma: the cholesky decomp of Cinv
%     lambda2_range: vector of lambda values to try -- e.g. beg:inc:end
%     X: pixel weight matrix
%     Z: design matrix for bias parameters
%     y_vpeak: data vector of RSS values
%     theta: true SLF image (col vector)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    

%if matlabpool('size') == 0; matlabpool open; end;
MSE_err = NaN(1,length(lambda2_range)); %store the MSE values
thetahat_store = NaN([imgdims length(lambda2_range)]); %store the image estimates

parfor ind = 1:length(lambda2_range);
    lambda2 = lambda2_range(ind);

    %solve the CVX model for given parameters
    [theta_hat, ~] = f_CVX_TikReg(imgdims,y_vpeak,X,Z,lambda2,Gamma);
    thetahat_store(:,:,ind) = reshape(theta_hat,imgdims);

    % Tik. Reg. errors  %
    MSE_err(ind) =  mean( (theta_hat - theta).^2 );

end

% %   %%%DEBUG PLOT CODE%%%
% for ii = 1:length(lambda2_range)
%   figure('name',['Tik. Reg. Solution, lambda2 = ' num2str(lambda2_range(ii))]); 
%   imshow(thetahat_store(:,:,ii),[0,max(theta(:))],'initialmagnification','fit');
% end
    
% find the optimal alpha from the search %
[~,ind] = min(MSE_err); %index of lowest total error
lambda2_MSE = lambda2_range(ind);
thetahat_MSE = reshape( thetahat_store(:,:,ind), imgdims(1)*imgdims(2), 1); 

%     %%%DEBUG PLOT CODE%%%
%     figure('name','L curve plot'); plot(data_err,norm_err); %plot the L curve
%     xlim([0 max([data_err norm_err])]); ylim([0 max([data_err norm_err])]);
%     save('I:\Research\RTI Mixed Models\matlab\workspace savedata\lambda2_search'); %store for analysis
% end

end

