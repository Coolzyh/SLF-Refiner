function [ D ] = f_calc_imgrad( M, N )
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% f_calc_imgrad 
%       This function computes a "first difference operator" to approximate
%       the gradient of an image
% OUTPUTS: 
%     D: gradient operator for the MxN image
% INPUTS:
%     M,N: # of pixels (rows, columns)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%define the forward difference matrices (x and y directions)
col = zeros(1,M*N); col(1) = -1; col(end) = 1;
row = zeros(1,M*N); row(1) = -1; row(2) = 1;
Dy = toeplitz(col,row); 
col = zeros(1,M*N); col(1) = -1; col(M*N-M+1) = 1;
row = zeros(1,M*N); row(1) = -1; row(M+1) = 1;
Dx = toeplitz(col,row);
D = (Dx'*Dx + Dy'*Dy); %full difference operator
D = -D;                %correct for forward difference
D(find(eye(M*N))) = -2*ones(1,M*N); %scale diagonal correctly


% data_err = zeros(1,length(alphaTR_range)); norm_err = zeros(1,length(alphaTR_range)); %error vects
% ind = 1;
% for alphaTR = alphaTR_range
% 
% % FORWARD DIFF TIK.REG. INVERT %
% ghat_TR = (B'*B + alphaTR * D ) \ B' * etahat_los;
% 
% % Tik. Reg. errors  %
% Gamma = chol(D); %find gamma matrix
% data_err(ind) = sum( (B*ghat_TR - etahat_los) .^2 );
% norm_err(ind) = sum( (Gamma*ghat_TR ) .^ 2 );
% 
% ind = ind + 1;
% end
% 
% % find the optimal alpha from the search %
% tot_err = data_err + norm_err;
% [~,ind] = min(tot_err); %index of lowest total error
% opt_alphaTR = alphaTR_range(ind);
% 
% % BEST ALPHA VALUE IMAGE INVERSION %
% ghat_TR = (B'*B + opt_alphaTR * D ) \ B' * etahat_los;
% ghat_TR = reshape(ghat_TR,M,N); 

end

