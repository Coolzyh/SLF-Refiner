function [ betahat_Lcurve, lambda2_Lcurve ] = f_lambda2_Lcurve( imgdims, Gamma, ...
                                                lambda2_range, X, Z, y_vpeak )
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% SOLVE FOR THE VALUE OF LAMBDA2 USING TIKHONOV REGULARIZATION AND THE L CURVE 
%       This function finds the value of the lambda2 parameter (that goes with the 2 norm error 
% term) using the L-curve method.  It balances the data error and the regularization perturbation.
% The lambda2 parameter is found first, with lambda1 (1 norm penalty) set to 0, so that all
% variables are included in the model. REQUIRES parallel computing toolbox to use parfor.
% OUTPUTS: 
%     betahat_Lcurve: MxN estimated image
%     lambda2_Lcurve: optimum value found via the L-curve which approximately minimizes the total
%     errors.
% INPUTS:
%     imgdims: size of image (rows, columns)
%     Gamma: the cholesky decomp of Cinv
%     lambda2_range: vector of lambda values to try -- e.g. beg:inc:end
%     X: pixel weight matrix
%     Z: design matrix for bias parameters
%     y_vpeak: data vector of RSS values
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 

if length(lambda2_range) == 1 % lambda2 is given
    %solve the CVX tikhonov model for given parameters
    lambda2 = lambda2_range(1);
    cvx_begin
        variable beta_hat(imgdims(1)*imgdims(2),1) nonnegative
        variable bhat(size(Z,2),1) nonnegative
        minimize norm(y_vpeak - X*beta_hat - Z*bhat) + lambda2 * norm(Gamma * beta_hat)
    cvx_end
    betahat_Lcurve = reshape(beta_hat,imgdims);
    lambda2_Lcurve = lambda2;
    
else % use the L curve method %
    if matlabpool('size') == 0; matlabpool open; end;
    data_err = zeros(1,length(lambda2_range)); norm_err = zeros(1,length(lambda2_range)); %error vects
    betahat_store = NaN([imgdims length(lambda2_range)]); %store the image estimates

    parfor ind = 1:length(lambda2_range);
        lambda2 = lambda2_range(ind);
        
        %solve the CVX tikhonov model for given parameters
        [beta_hat, bhat] = f_CVX_TikReg(imgdims,y_vpeak,X,Z,lambda2,Gamma);
        betahat_store(:,:,ind) = reshape(beta_hat,imgdims);

        % Tik. Reg. errors  %
        data_err(ind) = norm( y_vpeak - X*beta_hat - Z*bhat);
        norm_err(ind) = norm( Gamma*beta_hat );
    end

%   %%%DEBUG PLOT CODE%%%
%   figure('name',['Tik. Reg. Solution, lambda2 = ' num2str(lambda2)]); 
%   imshow(betahat_Lcurve(:,:,ii),[0,max(betahat_Lcurve(:,:,ii))],'initialmagnification','fit');
    
    % find the optimal alpha from the search %
    tot_err = data_err + norm_err;
    [~,ind] = min(tot_err); %index of lowest total error
    lambda2_Lcurve = lambda2_range(ind);
    betahat_Lcurve = betahat_store(:,:,ind); 

%     %%%DEBUG PLOT CODE%%%
%     figure('name','L curve plot'); plot(data_err,norm_err); %plot the L curve
%     xlim([0 max([data_err norm_err])]); ylim([0 max([data_err norm_err])]);
%     save('I:\Research\RTI Mixed Models\matlab\workspace savedata\lambda2_search'); %store for analysis
end

end

