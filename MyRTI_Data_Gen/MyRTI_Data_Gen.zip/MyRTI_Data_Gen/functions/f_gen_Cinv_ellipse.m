function [ ghat_ell, Cg_ell, Gamma1 ] = ...
    f_gen_Cinv_ellipse( theta, grid, sig2x, M, N, kappa_x, kappa_y, B, etahat_los)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FUNC_GHAT_SOLVE_CVX: estimate tomographic image using convex optimization with positive 
%       constraint.  uses the elliptical covariance model with constraint ghat>=0
% OUTPUTS: 
%     ghat_ell: MxN estimated image using the CVX tool with positivity constraint 
%     Cg_ell: ellipse covariance matrix specified by the input parameters
%     Gamma1: cholesky decomposition of Cg, used in minimizing the Tik. Reg. cost function
% INPUTS:
%     theta: # of receiver nodes (total, INT multiple of 4)
%     sig2x: a-priori pixel variance, dB^2
%     M,N: # of pixels (rows, columns)
%     grid: y,x coordinate of each pixel (func_gen_nodegrid)
%     kappa_x, kappa_y: spatial covar spread parameter
%     B: pixel weight matrix
%     etahat_los: synthetic data vector (func_gen_LOSdata)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%Define the CCW rotation by theta (degrees): 
rot_mat = [cosd(theta) -sind(theta); sind(theta) cosd(theta)]'; 
%dmn_x and dmn_y: SIGNED distance from pixel m to pixel n in the respective direction
[m n] = ndgrid(1:M*N,1:M*N); 
dmn_x =  grid(m,2) - grid(n,2); dmn_y = grid(m,1) - grid(n,1);
dmn_yx = rot_mat * [dmn_y dmn_x]';  %rotate y,x coordinates by theta
dmn_yx = dmn_yx';

%Cg_ell: ellipse-shaped spatial covar matrix
Cg_ell = (sig2x) * exp( -sqrt( (dmn_yx(:,2)/kappa_x).^2 + (dmn_yx(:,1)/kappa_y).^2 ) );
Cg_ell = reshape(Cg_ell,M*N,M*N);
Gamma1 = chol(inv(Cg_ell)); %find gamma matrix for cost function

% CVX MODEL INVERSION WITH CONSTRAINTS %
cvx_begin 
    variable ghat_ell(M*N,1)
    minimize( norm(B*ghat_ell - etahat_los , 2) + norm(Gamma1*ghat_ell , 2) );
    subject to 
        ghat_ell >= 0;
cvx_end
ghat_ell = reshape(ghat_ell,M,N);

end