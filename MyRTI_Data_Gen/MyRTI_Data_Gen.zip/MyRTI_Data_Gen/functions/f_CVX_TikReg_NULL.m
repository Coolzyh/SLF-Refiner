function [ thetahat_null ] = f_CVX_TikReg_NULL(imgdims, y, Xfesa, a0, alpha0, d, lambda2, Gamma )
%%% A WRAPPER FUNCTION TO ALLOW CVX CODE TO RUN IN A PARFOR LOOP %%%
%%% THIS ONE COMPUTES THE TIKHONOV REGULARIZATION IGNORING THE RANDOM EFFECTS
%%% (ASSUMES THEY ARE KNOWN)
NT = length(y);
cvx_begin quiet %for the naiive approach
    variable thetahat_null(imgdims(1)*imgdims(2),1) 
    minimize norm(y - Xfesa*thetahat_null - a0*ones(NT,1) - alpha0*d) + ...
                    lambda2 * norm(Gamma*thetahat_null)
cvx_end


end

