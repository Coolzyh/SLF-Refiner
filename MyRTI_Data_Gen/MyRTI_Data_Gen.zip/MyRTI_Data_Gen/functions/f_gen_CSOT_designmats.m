function [ X, Z, Zfesa, Znull ] = f_gen_CSOT_designmats( M, y_vpeak, Tw, nodepos, pixelsize, ...
                                                          imgorg, imgdims )
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% GENERATE THE DESIGN MATRICES USED FOR IMAGE RECONSTRUCION ON THE CSOT                           
% Inputs:
%   M - number of CSOT nodes (16)
%   y_vpeak - NT x 1 vector of RSS values   Tw - number of time steps
%   nodepos - M x Tw complex matrix of node positions   pixelsize - l/w of a pixel in m
%   imgorg - position of the lower left corner of the image (x,y) in m
%   imgdims - rows,cols in the image
% Outputs:
%   X - (NT x pixelcount) pixel weight matrix by tomographic projections
%   Z,Zfesa,Znull - design mats for the fixed effects depending on model
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

N = M*(M-1)-M; %CSOT useful link count
NT = size(y_vpeak,1); %total data size
ni = Tw; X = []; Z = []; d = []; Znull = []; Zfesa = [];
for i1 = 1:M
    for i2 = 1:M
        %ensure you ignore the "fake" links in CSOT!
        if i1==i2 || (mod(i1,2)==1 && i2==i1+1) || (mod(i1,2)==0 && i1==i2+1)
            continue
        else
            Xi = f_gen_Wi(nodepos,pixelsize,imgorg,imgdims,i1,i2);  %FE design
            di = abs( nodepos(i1,:) - nodepos(i2,:) )';      %link lengths
            di = 20 * log10( di );                           %log distance
            Zi = [ones(ni,1) -di];                           %random effects design matrix

            d = [d; -di;];                                    %full distance vector for FESA model
            Zfesa = blkdiag(Zfesa,ones(ni,1));               %fixed effects design for FESA
            Znull = [Znull; Zi];                             %stacked Z mat for NULL model
            X = [X; -Xi];                                     %full weights matrix (NEGATIVE!)
            Z = blkdiag(Z,Zi);                               %full RE design matrix
        end
    end
end
Zfesa = [d, Zfesa]; %encode the single alpha as first element of b_hat
end

