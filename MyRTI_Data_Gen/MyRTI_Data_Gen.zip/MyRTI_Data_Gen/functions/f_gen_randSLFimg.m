function [ SLF_rand ] = f_gen_randSLFimg( M,N,dBwhite,wallcount_vec )
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% func_gen_randSLFimg: generate a random spatial loss field image consisting of wall pieces        %
%   M,N: # of rows/cols in the image, 5x5 pixel MINIMUM                                            %
%   dBwhite: maximum attenuation for a wall pixel (dB)                                             %
%   wallcount_vec: [VMIN VMAX HMIN HMAX SMIN SMAX] 
%   the bounds on the possible count of vert. , horz. walls and squares                            %
%                                                                                                  %
% OUTPUTS:                                                                                         %
% SLF_rand: the randomly generated spatial loss field image                                        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

SLF_rand = zeros(M,N); 
num_vwalls = randi(wallcount_vec(1:2),1); %random number of vertical walls in the image
num_hwalls = randi(wallcount_vec(3:4),1); %" " horizontal walls
num_square = randi(wallcount_vec(5:6),1); %" " horizontal walls

vwall_len = randi([4 floor(0.6*M)],num_vwalls,1); %length of each vertical wall
hwall_len = randi([4 floor(0.6*N)],num_hwalls,1); %"" horiz. wall
squ_len=randi([1 floor(0.1*min(M,N))],num_square,1); %square len

vwall_atten = 0.6*dBwhite + rand(num_vwalls,1)*(0.4*dBwhite); %attenuations of each wall
hwall_atten = 0.6*dBwhite + rand(num_hwalls,1)*(0.4*dBwhite);
squ_atten= 0.6*dBwhite + rand(num_square,1)*(0.4*dBwhite);

vwall_pos = zeros(num_vwalls,2); %store row,col of start of each vwall
hwall_pos = zeros(num_hwalls,2); % " " hwall
squ_pos = zeros(num_square,2);
vwall_width = zeros(num_vwalls,1);
hwall_width = zeros(num_hwalls,1);
for i = 1:num_vwalls
    vwall_width(i)=randi([1 max(1,floor(0.18*vwall_len(i)))],1);   %ith wall's width
    vwall_pos(i,1) = randi(M-vwall_len(i)+1,1); %row pos of vert wall i  
    vwall_pos(i,2) = randi(N-vwall_width(i)+1,1);              %col pos " "
end
for i = 1:num_hwalls
    hwall_width(i)=randi([1 max(1,floor(0.18*hwall_len(i)))],1);   %ith wall's width
    hwall_pos(i,1) = randi(M-hwall_width(i)+1,1);              %row pos of horiz. wall i
    hwall_pos(i,2) = randi(N-hwall_len(i)+1,1); %col pos " "
end
for i = 1:num_square
    squ_pos(i,1) = randi(M-squ_len(i)+1,1); %row pos of square wall i  
    squ_pos(i,2) = randi(N-squ_len(i)+1,1);              %col pos " "
end

%fill in the wall attenuation values
for i = 1:num_vwalls
    SLF_rand( vwall_pos(i,1):(vwall_pos(i,1)+vwall_len(i)-1) , vwall_pos(i,2):(vwall_pos(i,2)+vwall_width(i)-1) ) = vwall_atten(i);
end
for i = 1:num_hwalls
    SLF_rand( hwall_pos(i,1):(hwall_pos(i,1)+hwall_width(i)-1) , hwall_pos(i,2):(hwall_pos(i,2)+hwall_len(i)-1) ) = hwall_atten(i);
end
for i = 1:num_square
    SLF_rand( squ_pos(i,1):(squ_pos(i,1)+squ_len(i)-1) , squ_pos(i,2):(squ_pos(i,2)+squ_len(i)-1) ) = squ_atten(i);
end

% % DEBUG PLOT CODE %
% imshow(SLF_rand,[0 dBwhite],'initialmagnification','fit');

end

