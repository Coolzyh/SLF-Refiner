function [ beta_hat, bhat ] = f_CVX_ENet(imgdims, y_vpeak, X, Z, Gamma, lambda1, lambda2 )
%WRAPPER FUNCTION TO ALLOW CVX TO RUN WITHIN A PARFOR LOOP
% this is the actual elastic net model
cvx_begin quiet
    variable beta_hat(imgdims(1)*imgdims(2),1) nonnegative
    variable bhat(size(Z,2),1) nonnegative
    minimize norm(y_vpeak - X*beta_hat - Z*bhat) + lambda1 * norm(beta_hat,1) + ...
                    lambda2 * norm(Gamma * beta_hat) %+ lambda2 * norm(bhat);
cvx_end

end

