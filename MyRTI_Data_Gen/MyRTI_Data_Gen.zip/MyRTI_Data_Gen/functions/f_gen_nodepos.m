function [ nodepos ] = f_gen_nodepos( M, Tw, areabounds, node_vel )
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% GENERATE THE "TRUE" NODE POSITIONS OVER TIME
% M - total number of nodes
% Tw - number of time steps / waypoints
% areabounds - [xmin xmax ymin ymax] the size of the test area for node moves
% node_vel - stdev of velocity perturbations
%
% nodepos (M x Tw) (COMPLEX) - vector of each node's position at each time step
% the (x,y) coordinates are stored as the real and imag parts of nodepos
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

nodepos = NaN(M,Tw);

%random node start locations INSIDE the image
for i = 1:M
    nodepos(i,1) = (areabounds(1) + (areabounds(2)-areabounds(1))*rand(1,1)) + ...
        (1j * (areabounds(3) + (areabounds(4)-areabounds(3)).*rand(1,1)) );
end

%assign random node trajectories
for i = 1:M
    for t = 2:Tw 
        nodepos(i,t) = nodepos(i,t-1) + node_vel*randn(1,1) + sqrt(-1)*node_vel*randn(1,1); 
        
        %fix out of bounds conditions by 'pushing away' from the area bounds
        if real(nodepos(i,t)) < areabounds(1)
            nodepos(i,t) = areabounds(1)+node_vel + 1j*imag(nodepos(i,t)); %left border
        elseif real(nodepos(i,t)) > areabounds(2) 
            nodepos(i,t) = areabounds(2)-node_vel + 1j*imag(nodepos(i,t)); %right border
        elseif imag(nodepos(i,t)) < areabounds(3) 
            nodepos(i,t) = real(nodepos(i,t)) + 1j*(areabounds(3)+node_vel); %bottom border
        elseif imag(nodepos(i,t)) > areabounds(4); 
            nodepos(i,t) = real(nodepos(i,t)) + 1j*(areabounds(4)-node_vel); %top border
        end
        
    end
end

% %plot debugger
% close all; figure(1);
% for i = 1:M
%     hold on
%     plot(real(nodepos(i,:)),imag(nodepos(i,:)),'-rx')
% end

end

