%test the average variance of an image
clear; clc; tic;
dBwhite = 12;
wallcount_vec = [2 4 2 4];
iters = 1.5e6; %number of image samples
imgdims = [32 32];


K = imgdims(1) * imgdims(2); 
PIXVARS = NaN(1,iters);
img_stor = NaN(iters,K);
for ii = 1:iters
    
    img = f_gen_randSLFimg(imgdims(1),imgdims(2),dBwhite,wallcount_vec);
    img = reshape(img,1,K);
    
    PIXVARS(ii) = var(img(:));
    
    img_stor(ii,:) = img;
end

IMGCOV = cov(img_stor);
AVG = mean(PIXVARS);

% IMGCOV(abs(IMGCOV) < 1e-6) = 0; %numerical precision

save('I:\Research\RTI Mixed Models\matlab\workspace savedata\img_covdata');
toc;